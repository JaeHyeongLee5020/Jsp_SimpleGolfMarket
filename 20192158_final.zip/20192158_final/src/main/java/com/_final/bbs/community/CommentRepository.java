package com._final.bbs.community;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    // CommunityPost 엔티티로 댓글 조회
    List<Comment> findByPost(CommunityPost post);

    // post_id로 댓글 조회
    List<Comment> findByPostId(Long postId);


    List<CommunityPost> findTop30ByOrderByCreatedAtDesc();
}
