package com._final.bbs.repository;

import com._final.bbs.domain.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    List<Post> findTop2ByOrderByCreatedAtDesc(); // 최신 게시글 2개 가져오기
}
