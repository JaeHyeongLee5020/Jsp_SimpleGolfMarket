package com._final.bbs.controller;

import com._final.bbs.community.CommunityPostRepository;
import com._final.bbs.community.CommunityPost;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MainController {

    private final CommunityPostRepository communityPostRepository;

    public MainController(CommunityPostRepository communityPostRepository) {
        this.communityPostRepository = communityPostRepository;
    }

    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        // 로그인 여부 확인
        String loggedInUser = (String) session.getAttribute("username");
        boolean loggedIn = (loggedInUser != null);

        // 최신 게시글 2개 가져오기
        List<CommunityPost> latestPosts = communityPostRepository.findTop2ByOrderByCreatedAtDesc();
        if (latestPosts != null && !latestPosts.isEmpty()) {
            System.out.println("Latest Posts: " + latestPosts); // 디버깅 로그
        } else {
            System.out.println("No latest posts found."); // 데이터 없을 경우
        }

        // 모델에 데이터 추가
        model.addAttribute("loggedIn", loggedIn);
        model.addAttribute("username", loggedInUser);
        
        model.addAttribute("latestPosts", latestPosts);

        return "index";
    }
    
}
 //로그인 전 nabvar 확인, 거리계산 확인 > 회원가입, 로그인  > 내 정보 수정 > 나의 기록실
//> 메인화면 최신글 보여주고 조인 게시판 작성 후 보여주기 > 추천 및 댓글 기능  