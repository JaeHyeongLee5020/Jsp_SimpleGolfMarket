package com._final.bbs.community;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.stream.IntStream;

@Component
public class DataInitializer implements CommandLineRunner {

    private final CommunityPostRepository postRepository;

    public DataInitializer(CommunityPostRepository postRepository) {
        this.postRepository = postRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // 기존 데이터 확인 후, 30개 이상의 데이터가 없을 경우 추가
        if (postRepository.count() < 30) {
            long existingCount = postRepository.count();
            IntStream.range(0, 30).forEach(i -> {
                CommunityPost post = new CommunityPost();
                post.setTitle("추가된 게시글 " + (existingCount + 30 - i));  // 기존 데이터 개수부터 추가
                post.setContent("추가된 게시글 내용 " + (existingCount + 30 - i));
                post.setAuthor("작성자 " + (existingCount + 30 - i));
                post.setCreatedAt(LocalDateTime.now().minusDays(30 - i));
                postRepository.save(post);
            });
        }
    }

}
