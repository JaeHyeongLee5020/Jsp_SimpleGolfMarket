package com._final.bbs.controller;

import com._final.bbs.domain.User;
import com._final.bbs.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserRepository userRepository;

    @Autowired
    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public String login(
        @RequestParam(name = "username", required = false) String username,
        @RequestParam(name = "password", required = false) String password,
        HttpSession session
    ) {
        if (username == null || username.isEmpty()) {
            return "redirect:/?error=empty_username";
        }
        if (password == null || password.isEmpty()) {
            return "redirect:/?error=empty_password";
        }

        return userRepository.findByUsername(username)
                .filter(user -> user.getPassword().equals(password))
                .map(user -> {
                    session.setAttribute("username", username);
                    return "redirect:/";
                })
                .orElse("redirect:/?error=login_failed");
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/signup")
    public String signupForm() {
        return "signup";
    }

    @GetMapping("/records")
    public String recordsPage() {
        return "records"; 
    }


    @PostMapping("/signup")
    public String signup(
        @RequestParam(name = "name") String name,
        @RequestParam(name = "email") String email,
        @RequestParam(name = "phone") String phone,
        @RequestParam(name = "username") String username,
        @RequestParam(name = "password") String password,
        @RequestParam(name = "passwordConfirm") String passwordConfirm
    ) {
        if (!password.equals(passwordConfirm)) {
            return "redirect:/signup?error=password_mismatch";
        }
        if (userRepository.findByUsername(username).isPresent()) {
            return "redirect:/signup?error=username_exists";
        }

        // 새로운 필드 저장
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPhone(phone);
        user.setUsername(username);
        user.setPassword(password);
        userRepository.save(user);

        return "redirect:/";
    }

}
