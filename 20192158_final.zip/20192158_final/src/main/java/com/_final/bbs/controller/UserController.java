package com._final.bbs.controller;

import com._final.bbs.domain.User;
import com._final.bbs.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/myinfo")
public class UserController {

    private final UserRepository userRepository;

    @Autowired
    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    public String showMyInfo(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        User user = userRepository.findByUsername(username).orElse(null);
        model.addAttribute("user", user);
        return "myinfo";
    }

    @GetMapping("/edit")
    public String showPasswordVerification() {
        return "verify_password";
    }

    @PostMapping("/edit")
    public String verifyPassword(
        @RequestParam("password") String password, 
        HttpSession session, 
        Model model
    ) {
        String username = (String) session.getAttribute("username");
        User user = userRepository.findByUsername(username).orElse(null);

        if (user != null && user.getPassword().equals(password)) {
            model.addAttribute("user", user);
            return "edit_info";
        }
        return "redirect:/myinfo/edit?error=invalid_password";
    }

    @PostMapping("/edit/save")
    public String saveEditedInfo(
        @RequestParam("name") String name,
        @RequestParam("email") String email,
        @RequestParam("phone") String phone,
        HttpSession session
    ) {
        String username = (String) session.getAttribute("username");
        User user = userRepository.findByUsername(username).orElse(null);

        if (user != null) {
            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);
            userRepository.save(user);
        }
        return "redirect:/myinfo";
    }
}
