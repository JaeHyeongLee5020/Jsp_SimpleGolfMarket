package com._final.bbs.community;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/community")
public class CommunityController {

    private final CommunityPostRepository postRepository;
    private final CommentRepository commentRepository;

    public CommunityController(CommunityPostRepository postRepository, CommentRepository commentRepository) {
        this.postRepository = postRepository;
        this.commentRepository = commentRepository;
    }

    // 게시판 목록 (페이징 처리, 최신순)
    @GetMapping
    public String listPosts(@RequestParam(value = "keyword", required = false) String keyword,
                            @RequestParam(value = "page", defaultValue = "0") int page, // 기본값 0으로 설정
                            Model model) {

        // 최신순 정렬
        Pageable pageable = PageRequest.of(page, 10, Sort.by("createdAt").descending());

        // 검색어 처리
        Page<CommunityPost> postsPage;
        if (keyword != null && !keyword.isEmpty()) {
            postsPage = postRepository.findByTitleContainingIgnoreCaseOrderByCreatedAtDesc(keyword, pageable);
        } else {
            postsPage = postRepository.findAll(pageable);
        }

        // 모델에 전달
        model.addAttribute("posts", postsPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", postsPage.getTotalPages());

        return "community"; // 게시판 뷰
    }

    // 최신 게시글 2개
    @GetMapping("/latest")
    public String getLatestPosts(Model model) {
        List<CommunityPost> latestPosts = postRepository.findTop2ByOrderByCreatedAtDesc();
        model.addAttribute("latestPosts", latestPosts);
        return "index"; // 메인 페이지에서 사용
    }

    // 게시글 작성 폼
    @GetMapping("/write")
    public String writePostForm(Model model) {
        model.addAttribute("post", new CommunityPost());
        return "community_write";
    }

    // 게시글 작성 처리
    @PostMapping("/write")
    public String savePost(@ModelAttribute CommunityPost post, Model model) {
        if (post.getAuthor() == null || post.getAuthor().isEmpty()) {
            model.addAttribute("error", "작성자를 입력하세요.");
            model.addAttribute("post", post);
            return "community_write";
        }

        post.setCreatedAt(LocalDateTime.now());
        postRepository.save(post);
        return "redirect:/community";
    }

    // 게시글 상세 보기
    @GetMapping("/{id}")
    public String viewPost(@PathVariable("id") Long id, Model model) {
        CommunityPost post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));

        List<Comment> comments = commentRepository.findByPostId(id);
        model.addAttribute("post", post);
        model.addAttribute("comments", comments);

        return "community_view";
    }

    // 게시글 추천
    @PostMapping("/{id}/like")
    public String likePost(@PathVariable("id") Long id) {
        CommunityPost post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));
        post.setLikes(post.getLikes() + 1);
        postRepository.save(post);
        return "redirect:/community/" + id;
    }

    // 게시글 수정 폼
    @GetMapping("/{id}/edit")
    public String editPostForm(@PathVariable("id") Long id, Model model) {
        CommunityPost post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));
        model.addAttribute("post", post);
        return "community_write";
    }

    // 게시글 수정 처리
    @PostMapping("/{id}/edit")
    public String updatePost(@PathVariable("id") Long id, @ModelAttribute CommunityPost updatedPost, Model model) {
        CommunityPost post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));

        if (updatedPost.getTitle() == null || updatedPost.getTitle().isEmpty() ||
                updatedPost.getContent() == null || updatedPost.getContent().isEmpty()) {
            model.addAttribute("error", "제목과 내용을 모두 입력하세요.");
            model.addAttribute("post", updatedPost);
            return "community_write";
        }

        post.setTitle(updatedPost.getTitle());
        post.setContent(updatedPost.getContent());
        postRepository.save(post);
        return "redirect:/community/" + id;
    }

    // 댓글 추가
    @PostMapping("/{id}/comments")
    public String addComment(@PathVariable("id") Long id,
                              @RequestParam("content") String content,
                              @RequestParam("author") String author,
                              Model model) {

        CommunityPost post = postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다."));

        if (content.trim().isEmpty()) {
            model.addAttribute("error", "댓글 내용을 입력하세요.");
            return "redirect:/community/" + id;
        }

        Comment comment = new Comment();
        comment.setContent(content);
        comment.setAuthor(author);
        comment.setCreatedAt(LocalDateTime.now());
        comment.setPost(post);

        commentRepository.save(comment);
        return "redirect:/community/" + id;
    }

    // 인기 게시글 (추천수가 10 이상)
    @GetMapping("/popular")
    public String popularPosts(Model model) {
        List<CommunityPost> popularPosts = postRepository.findByLikesGreaterThanEqualOrderByCreatedAtDesc(10);
        model.addAttribute("posts", popularPosts);
        return "community_popular"; // 별도의 인기 게시글 뷰
    }
}
