package com._final.bbs.controller;

import com._final.bbs.user.SiteUser;
import com._final.bbs.user.SiteUserService;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user/login") // 경로 변경으로 충돌 방지
public class LoginController {

    private final SiteUserService siteUserService;

    public LoginController(SiteUserService siteUserService) {
        this.siteUserService = siteUserService;
    }

    @GetMapping
    public String loginForm() {
        return "login"; // 로그인 페이지
    }

    @PostMapping
    public String login(@RequestParam String username, 
                        @RequestParam String password, 
                        HttpSession session, 
                        Model model) {
        SiteUser user = siteUserService.findByUsername(username);
        if (user == null || !user.getPassword().equals(password)) {
            model.addAttribute("error", "아이디 또는 비밀번호가 잘못되었습니다.");
            return "login";
        }

        session.setAttribute("loggedIn", true);
        session.setAttribute("name", user.getName());

        // 디버깅 로그
        System.out.println("Logged in user: " + user.getName());
        System.out.println("Session name: " + session.getAttribute("name"));

        return "redirect:/index";
    }


}
