package com._final.bbs.community;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommunityPostRepository extends JpaRepository<CommunityPost, Long> {

    // 제목으로 검색하여 최신순으로 정렬, Pageable로 페이징 처리
    Page<CommunityPost> findByTitleContainingIgnoreCaseOrderByCreatedAtDesc(String keyword, Pageable pageable);

    // 최신 2개 게시글 가져오기
    List<CommunityPost> findTop2ByOrderByCreatedAtDesc();

    // 최신 30개 게시글 가져오기
    List<CommunityPost> findTop30ByOrderByCreatedAtDesc();

    // 모든 게시글을 최신순으로 페이지 처리
    Page<CommunityPost> findAll(Pageable pageable);

    // 특정 작성자의 게시글 가져오기 (최신순)
    List<CommunityPost> findByAuthorOrderByCreatedAtDesc(String author);

    // 제목과 내용을 동시에 검색 (최신순)
    Page<CommunityPost> findByTitleContainingIgnoreCaseOrContentContainingIgnoreCaseOrderByCreatedAtDesc(String titleKeyword, String contentKeyword, Pageable pageable);

    // 추천 수가 특정 값 이상인 게시글 가져오기
    List<CommunityPost> findByLikesGreaterThanEqualOrderByCreatedAtDesc(int likes);
}
